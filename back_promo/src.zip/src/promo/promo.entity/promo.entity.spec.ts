import { PromoEntity } from './promo.entity';

describe('PromoEntity', () => {
  it('should be defined', () => {
    expect(new PromoEntity()).toBeDefined();
  });
});
