import { Promo } from 'src/promo/promo.entity/promo.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToMany } from 'typeorm';

@Entity()
export class Matiere{
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ length: 45 })
    libelle:string;
    @ManyToMany(() => Promo, (promo) => promo.matieres)
  promos: Promo[];
}
