import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PromoService } from './promo.service';
import { PromoController } from './promo.controller';
import { Promo } from './promo.entity/promo.entity';
import { MatieresModule } from 'src/matiere/matiere.module';
import { MatiereService } from 'src/matiere/matiere.service';

@Module({
  imports: [TypeOrmModule.forFeature([Promo])],//,MatieresModule],
  providers: [PromoService],//MatiereService],
  controllers: [PromoController]
})

export class PromoModule {}
