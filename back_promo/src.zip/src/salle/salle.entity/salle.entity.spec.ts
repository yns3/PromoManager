import { SalleEntity } from './salle.entity';

describe('SalleEntity', () => {
  it('should be defined', () => {
    expect(new SalleEntity()).toBeDefined();
  });
});
