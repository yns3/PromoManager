import { UtilisateurEntity } from './utilisateur.entity';

describe('UtilisateurEntity', () => {
  it('should be defined', () => {
    expect(new UtilisateurEntity()).toBeDefined();
  });
});
