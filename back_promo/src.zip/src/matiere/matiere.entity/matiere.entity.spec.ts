import { MatiereEntity } from './matiere.entity';

describe('MatiereEntity', () => {
  it('should be defined', () => {
    expect(new MatiereEntity()).toBeDefined();
  });
});
